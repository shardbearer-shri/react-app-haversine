import "./App.css";
import MapsMath from "./components/MapsMath";
function App() {
  return (
    <div className="App">
      <MapsMath />
    </div>
  );
}

export default App;
